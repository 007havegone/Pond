#include "lpkit.h"


void lp_solve_presolve(lprec *lp)
{
  fprintf(stderr, "Entering presolve\n");


}

